( pcb2gcode 2.4.0 )
( Software-independent Gcode )

( This file uses only one drill bit. Forced by 'onedrill' option )

G94       (Millimeters per minute feed rate.)
G21       (Units == Millimeters.)
G90       (Absolute coordinates.)
G00 S12000     (RPM spindle speed.)

G00 Z25.00000 (Retract)
T1
M5      (Spindle stop.)
G04 P1.00000
(MSG, Change tool bit to drill size 0.8001mm)
M6      (Tool change.)
M0      (Temporary machine stop.)
M3      (Spindle on clockwise.)
G0 Z0.50000
G04 P1.00000

G1 F40.00000
G0 X3.27600 Y4.03800
G1 Z-1.75000
G1 Z0.50000
G0 X3.27600 Y8.22900
G1 Z-1.75000
G1 Z0.50000
G0 X8.35600 Y8.61000
G1 Z-1.75000
G1 Z0.50000
G0 X3.27600 Y14.32500
G1 Z-1.75000
G1 Z0.50000
G0 X3.27600 Y18.51600
G1 Z-1.75000
G1 Z0.50000
G0 X8.35600 Y16.73800
G1 Z-1.75000
G1 Z0.50000
G0 X14.45200 Y9.11800
G1 Z-1.75000
G1 Z0.50000
G0 X14.45200 Y5.56200
G1 Z-1.75000
G1 Z0.50000
G0 X26.51700 Y4.03800
G1 Z-1.75000
G1 Z0.50000
G0 X26.51700 Y18.51600
G1 Z-1.75000
G1 Z0.50000

G00 Z25.000 ( All done -- retract )

M5      (Spindle off.)
G04 P1.000000
M9      (Coolant off.)
M2      (Program end.)

